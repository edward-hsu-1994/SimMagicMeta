var lang = "zh-tw"
var memo ={
	"zh-tw" : '*注意事項:您目前所使用Google Chrome 版本不支援Silverlight、Java 和 Unity等外掛元件；請安裝IE TAB擴充元件觀看或使用IE瀏覽器觀看，安裝方式。<a href="Chorme IETab.pdf">請點我觀看說明</a>',
	"en" : '<a href="Chorme IETab.pdf">*Note:Refer to the link for installation instructions.</a>'
}
